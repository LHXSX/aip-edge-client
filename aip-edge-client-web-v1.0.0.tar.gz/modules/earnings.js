// 收益统计模块
export class EarningsManager {
    async loadEarnings() {
        // 加载收益数据
    }
}

// 缓存模块
export class CacheManager {}

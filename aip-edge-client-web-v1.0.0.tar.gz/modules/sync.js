// 同步模块
export class SyncManager {}

// 推荐模块
export class ReferralManager {}

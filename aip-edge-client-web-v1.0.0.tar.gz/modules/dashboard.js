// 仪表盘模块
export class DashboardManager {}

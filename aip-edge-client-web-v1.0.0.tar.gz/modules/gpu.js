// GPU算力模块
export class GPUManager {}

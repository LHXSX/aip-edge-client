// 远程控制模块
export class RemoteManager {}

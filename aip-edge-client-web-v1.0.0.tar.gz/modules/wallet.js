// 钱包模块
export class WalletManager {}

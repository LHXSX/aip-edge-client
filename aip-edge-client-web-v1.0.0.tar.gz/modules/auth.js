// 认证模块
export class AuthManager {}

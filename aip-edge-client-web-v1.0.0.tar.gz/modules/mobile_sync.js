// 移动端同步模块
export class MobileSyncManager {}

// 设置模块
export class SettingsManager {}

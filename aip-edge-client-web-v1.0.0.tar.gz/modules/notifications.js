// 通知模块
export class NotificationManager {}

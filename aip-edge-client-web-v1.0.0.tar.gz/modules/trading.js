// 算力交易模块
export class TradingManager {}

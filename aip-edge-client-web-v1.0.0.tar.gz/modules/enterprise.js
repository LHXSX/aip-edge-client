// 企业版模块
export class EnterpriseManager {}

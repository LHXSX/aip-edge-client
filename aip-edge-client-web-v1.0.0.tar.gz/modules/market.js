// 算力市场模块
export class MarketManager {}
